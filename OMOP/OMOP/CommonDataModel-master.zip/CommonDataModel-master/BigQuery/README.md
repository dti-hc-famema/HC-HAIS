Common-Data-Model / BigQuery
=================

This folder contains the script for Google BigQuery. It makes use of the #standardSql option. 
