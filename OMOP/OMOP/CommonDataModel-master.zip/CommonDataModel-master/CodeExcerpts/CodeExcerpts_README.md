# Code Excerpts Readme
--------

This folder is intended to house useful code excerpts related to the common data model, e.g. code for building the *_ERA tables. It will not be policed as heavily as the DDLs so use at your own discretion.